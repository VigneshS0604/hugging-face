from flask import Flask, request, jsonify, render_template
import os
from langchain_huggingface import HuggingFaceEndpoint

app = Flask(__name__)

# Set your Hugging Face API token using environment variable for security
sec_key = "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"
os.environ["HUGGINGFACEHUB_API_TOKEN"] = sec_key

# Repository ID for the model
repo_id = "mistralai/Mistral-7B-Instruct-v0.2"

# Initialize the HuggingFaceEndpoint
llm = HuggingFaceEndpoint(repo_id=repo_id, temperature=0.7)

# Common phrases dictionary with emojis
common_phrases = {
    "hi": "Hello! How can I assist you today? 👋",
    "hello": "Hi there! How can I help you? 👋",
    "hey": "Hey! What's up? 👋",
    "howdy": "Howdy! What can I do for you? 🤠",
    "greetings": "Greetings! How can I assist? 🙌",
    "how are you": "I'm just a bot, but I'm here to help you! How can I assist you today? 😊",
    "what's up": "Not much, just here to assist you! What can I help you with? 😊",
    "help": "Sure, I'm here to help! What do you need assistance with? 🤔",
    "thank you": "You're welcome! If you have any other questions, feel free to ask. 😊",
    "thanks": "You're welcome! Let me know if there's anything else I can do for you. 😊"
}

# Function to ask questions to the LLM
def ask_question(question: str):
    try:
        response = llm.invoke(question, max_length=128)  # Set max_length here
        return response
    except Exception as e:
        return str(e)

# Function to calculate sum of two numbers
def sum_numbers(a: int, b: int) -> int:
    return a + b

# Function to log conversation to a text file with UTF-8 encoding
def log_conversation(user_message, bot_response):
    with open("conversation_log.txt", "a", encoding="utf-8") as log_file:
        log_file.write(f"User: {user_message}\n")
        log_file.write(f"Bot: {bot_response}\n\n")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    question = data.get('question', '').lower()
    
    if not question:
        return jsonify({"response": "Please provide a question."}), 400
    
    if question in common_phrases:
        response = common_phrases[question]
        log_conversation(question, response)
        return jsonify({"response": response})
    
    if question == 'exit':
        response = "Exiting the session. Goodbye! 👋"
        log_conversation(question, response)
        return jsonify({"response": response})
    elif question.startswith('sum'):
        try:
            _, a, b = question.split()
            a, b = int(a), int(b)
            sum_result = sum_numbers(a, b)
            response = f"Sum of {a} and {b} is: {sum_result}"
            log_conversation(question, response)
            return jsonify({"response": response})
        except ValueError:
            response = "Invalid input for sum. Please provide two integers."
            log_conversation(question, response)
            return jsonify({"response": response}), 400
    else:
        try:
            response = ask_question(question)
            log_conversation(question, response)
            return jsonify({"response": response})
        except Exception as e:
            response = f"Error: {str(e)}"
            log_conversation(question, response)
            return jsonify({"response": response}), 500

if __name__ == '__main__':
    app.run(debug=True)
